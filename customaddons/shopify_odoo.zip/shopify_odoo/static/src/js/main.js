
console.log('test upload file js to shopify')